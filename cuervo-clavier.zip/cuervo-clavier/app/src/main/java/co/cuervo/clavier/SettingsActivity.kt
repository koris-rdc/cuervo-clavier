package co.cuervo.clavier

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class SettingsActivity : Activity() {

    private val reqImage = 41

    private lateinit var stateEnabled: TextView
    private lateinit var stateDefault: TextView
    private lateinit var stateReader: TextView
    private lateinit var emojiGrid: LinearLayout
    private lateinit var urlField: EditText
    private lateinit var keyField: EditText

    private val green = Color.parseColor("#1FA34A")
    private val dark = Color.parseColor("#1B1B22")
    private val grey = Color.parseColor("#5A5A6A")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EmojiStore.ensureInstalled(this)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(36), dp(20), dp(40))

        col.addView(title("Cuervo Clavier"))
        col.addView(body("Un clavier français avec IA intégrée et des émojis personnalisés."))

        // 1. Activer / choisir
        col.addView(section("1. Installer le clavier"))
        stateEnabled = body("")
        stateDefault = body("")
        col.addView(stateEnabled)
        col.addView(stateDefault)
        col.addView(button("Étape 1 : activer le clavier") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        col.addView(button("Étape 2 : choisir Cuervo Clavier") {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        })
        col.addView(small("Android ne permet pas à une application d'imposer son clavier : à l'étape 2, coche « Cuervo Clavier » dans la fenêtre qui s'ouvre. Il reste ensuite ton clavier jusqu'à ce que tu en choisisses un autre. Maintiens la barre d'espace pour changer de clavier."))

        // Zone de test
        col.addView(section("Essayer le clavier"))
        val test = EditText(this)
        test.hint = "Écris ici pour tester…"
        test.minLines = 3
        test.gravity = Gravity.TOP
        test.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        col.addView(test)

        // 2. IA
        col.addView(section("2. Intelligence artificielle"))
        col.addView(small("Colle l'adresse de ta fonction Supabase « ai-keyboard » et le mot de passe secret que tu as défini sur le serveur (CUERVO_TOKEN). La clé de l'IA reste sur le serveur, jamais dans l'application."))
        urlField = EditText(this)
        urlField.hint = "https://xxxx.supabase.co/functions/v1/ai-keyboard"
        urlField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        urlField.setText(Prefs.url(this))
        keyField = EditText(this)
        keyField.hint = "Mot de passe secret (CUERVO_TOKEN)"
        keyField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        keyField.setText(Prefs.key(this))
        col.addView(urlField)
        col.addView(keyField)
        col.addView(button("Enregistrer") {
            Prefs.save(this, urlField.text.toString(), keyField.text.toString())
            toast("Enregistré")
        })
        col.addView(button("Tester l'IA") { testAi() })
        col.addView(small("Pour des raisons de confidentialité, l'IA est désactivée dans les champs de mot de passe et n'envoie que le texte quand tu touches un bouton IA."))

        // 3. Émojis
        col.addView(section("3. Mes émojis personnalisés"))
        col.addView(small("Les 12 émojis Cuervo sont déjà dans le clavier (bouton 😀 puis ⭐). Ajoute les tiens depuis ta galerie. Touche un émoji pour le supprimer."))
        emojiGrid = LinearLayout(this)
        emojiGrid.orientation = LinearLayout.VERTICAL
        col.addView(emojiGrid)
        col.addView(button("Ajouter un émoji (image de la galerie)") {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(Intent.createChooser(i, "Choisir une image"), reqImage)
        })
        col.addView(small("Certaines applications (WhatsApp, Telegram…) acceptent les émojis image envoyés depuis un clavier ; les autres reçoivent l'émoji standard équivalent."))

        // 4. Lecture d'écran
        col.addView(section("4. Répondre aux messages"))
        col.addView(small("Dans une conversation, touche 💬 Répondre : le clavier lit les messages affichés et l'IA propose une réponse. La lecture se fait uniquement quand tu touches le bouton, jamais en continu, et les champs de mot de passe sont ignorés. Le texte lu est envoyé à l'IA via ton serveur. Sans cette option, copie un message puis touche 💬 Répondre."))
        stateReader = body("")
        col.addView(stateReader)
        col.addView(button("Activer la lecture d'écran") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(small("Dans la liste, ouvre « Cuervo Clavier » et active-le. Si Android affiche « Paramètre restreint » : ouvre « Infos de l'application », touche ⋮ en haut à droite, puis « Autoriser les paramètres restreints »."))
        col.addView(button("Infos de l'application") {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = android.net.Uri.parse("package:$packageName")
            startActivity(i)
        })

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.WHITE)
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshEmojis()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqImage && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) {
                val ok = EmojiStore.addFromUri(this, uri)
                toast(if (ok) "Émoji ajouté" else "Image illisible")
                refreshEmojis()
            }
        }
    }

    private fun refreshStatus() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val current = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        val isDefault = current.startsWith("$packageName/")
        val services = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        stateReader.text = if (services.contains("$packageName/")) "✅ Lecture d'écran activée" else "❌ Lecture d'écran non activée"
        stateEnabled.text = if (enabled) "✅ Clavier activé" else "❌ Clavier pas encore activé"
        stateDefault.text = if (isDefault) "✅ Cuervo Clavier est ton clavier actuel" else "❌ Ce n'est pas encore ton clavier actuel"
    }

    private fun refreshEmojis() {
        emojiGrid.removeAllViews()
        val files = EmojiStore.userFiles(this)
        if (files.isEmpty()) {
            emojiGrid.addView(small("Aucun émoji perso pour l'instant."))
            return
        }
        for (chunk in files.chunked(5)) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for (f in chunk) r.addView(thumb(f), LinearLayout.LayoutParams(0, dp(64), 1f))
            for (i in chunk.size until 5) r.addView(View(this), LinearLayout.LayoutParams(0, dp(64), 1f))
            emojiGrid.addView(r)
        }
    }

    private fun thumb(f: File): View {
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        img.setPadding(dp(6), dp(6), dp(6), dp(6))
        val bmp = BitmapFactory.decodeFile(f.absolutePath)
        if (bmp != null) img.setImageBitmap(bmp)
        img.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Supprimer cet émoji ?")
                .setPositiveButton("Supprimer") { _, _ ->
                    EmojiStore.delete(f)
                    refreshEmojis()
                }
                .setNegativeButton("Annuler", null)
                .show()
        }
        return img
    }

    private fun testAi() {
        Prefs.save(this, urlField.text.toString(), keyField.text.toString())
        toast("Test en cours…")
        val ctx: Context = this
        Thread {
            val r = AiClient.call(ctx, "corriger", "bonjour sa va bien, je suis content de te voir")
            runOnUiThread {
                val v = r.getOrNull()
                if (v != null) {
                    AlertDialog.Builder(this).setTitle("L'IA répond").setMessage(v)
                        .setPositiveButton("OK", null).show()
                } else {
                    AlertDialog.Builder(this).setTitle("Échec")
                        .setMessage(r.exceptionOrNull()?.message ?: "Erreur")
                        .setPositiveButton("OK", null).show()
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------- petits outils d'interface

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun title(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 28f
        v.setTypeface(null, Typeface.BOLD)
        v.setTextColor(dark)
        return v
    }

    private fun section(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 18f
        v.setTypeface(null, Typeface.BOLD)
        v.setTextColor(green)
        v.setPadding(0, dp(28), 0, dp(6))
        return v
    }

    private fun body(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 15f
        v.setTextColor(dark)
        v.setPadding(0, dp(4), 0, dp(4))
        return v
    }

    private fun small(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 13f
        v.setTextColor(grey)
        v.setPadding(0, dp(4), 0, dp(4))
        return v
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        val g = GradientDrawable()
        g.setColor(green)
        g.cornerRadius = dp(10).toFloat()
        b.background = g
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        lp.setMargins(0, dp(6), 0, dp(2))
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }
}
