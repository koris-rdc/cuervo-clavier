package co.cuervo.clavier

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import java.io.File

private val BG = Color.parseColor("#1B1B22")
private val KEY = Color.parseColor("#2E2E3A")
private val KEY_SPECIAL = Color.parseColor("#454556")
private val KEY_PRESSED = Color.parseColor("#6A6A80")
private val ACCENT = Color.parseColor("#1FA34A")
private val ACCENT_DARK = Color.parseColor("#146E32")
private val CHIP = Color.parseColor("#3A3A4C")
private val MUTED = Color.parseColor("#B8B8C8")

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

private val AI_ACTIONS = listOf(
    "💬 Répondre" to "repondre",
    "✨ Corriger" to "corriger",
    "🔁 Reformuler" to "reformuler",
    "👔 Pro" to "pro",
    "😊 Amical" to "amical",
    "✂️ Court" to "court",
    "🇬🇧 Anglais" to "en",
    "🇫🇷 Français" to "fr",
    "🇨🇬 Lingala" to "ln",
    "➕ Continuer" to "continuer"
)

private val EMOJI_TABS = listOf("⭐", "😀", "👍", "❤️", "🌴")

private val EMOJI_SETS = listOf(
    "",
    "😀 😃 😄 😁 😆 😅 😂 🤣 🙂 😉 😊 😇 🥰 😍 🤩 😘 😋 😛 😜 🤪 🤗 🤔 🤭 😐 😶 🙄 😏 😴 😌 😎 🤓 😕 😟 🙁 😮 😲 😳 🥺 😢 😭 😱 😖 😞 😤 😡 🤬 🥵 🥶 🤯 😷 🤒 🤢 🥳 😈 💀 👻 🤡",
    "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🖐️ 👋 🤚 👏 🙌 👐 🤲 🙏 🤝 💪 ✍️ 🤳 💅 👀 👅 👄 🧠 🙈 🙉 🙊",
    "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ✅ ❌ ⭕ ❗ ❓ ‼️ ⁉️ 💯 🔥 ⭐ 🌟 ✨ ⚡ 💥 💫 🎉 🎊 🎁 🏆 🥇 💰 💎 🔔 📌",
    "🐶 🐱 🐭 🐰 🦊 🐻 🐼 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🦅 🦋 🐝 🐢 🐍 🐟 🐘 🌳 🌴 🌹 🌻 🌞 🌙 🌈 ☔ 🍎 🍌 🍉 🍍 🥭 🍞 🍗 🍖 🍟 🍔 🍕 🥚 🍚 🍺 🥤 ☕ 🍰 ⚽ 🏀 🎵 🎧 📱 💻 🚗 🏍️ ✈️ 🏠 ⏰"
)

private val LETTER_ROWS = listOf("azertyuiop", "qsdfghjklm", "wxcvbn")
private val ACCENTS = "éèêàùçôîâûï"
private val SYM1_ROWS = listOf("1234567890", "@#€_&-+()/", "*\"':;!?")
private val SYM2_ROWS = listOf("~`|•√π÷×¶∆", "£$¥^°%{}[]", "<>=¿¡«»")

class CuervoIME : InputMethodService() {

    private val ui = Handler(Looper.getMainLooper())

    private lateinit var root: LinearLayout
    private lateinit var aiScroll: HorizontalScrollView
    private lateinit var aiRow: LinearLayout
    private lateinit var status: TextView
    private lateinit var keysBox: LinearLayout
    private lateinit var emojiBox: LinearLayout
    private lateinit var undoBtn: TextView

    private var shift = false
    private var caps = false
    private var lastShiftTap = 0L
    private var layer = 0            // 0 lettres, 1 chiffres/symboles, 2 autres symboles
    private var emojiOpen = false
    private var emojiTab = 0
    private var secure = false       // champ mot de passe : IA désactivée
    private var autoCap = false
    private var enterLabel = "⏎"

    private var lastOriginal: String? = null
    private var lastInserted: String? = null

    private val hideStatus = Runnable { status.visibility = View.GONE }

    // ---------------------------------------------------------------- cycle de vie

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        EmojiStore.ensureInstalled(this)

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        root.setPadding(dp(3), dp(3), dp(3), dp(6))

        aiScroll = HorizontalScrollView(this)
        aiScroll.isHorizontalScrollBarEnabled = false
        aiRow = LinearLayout(this)
        aiRow.orientation = LinearLayout.HORIZONTAL
        aiRow.gravity = Gravity.CENTER_VERTICAL
        aiScroll.addView(aiRow)
        buildAiBar()

        status = TextView(this)
        status.setTextColor(MUTED)
        status.textSize = 12f
        status.setPadding(dp(8), dp(2), dp(8), dp(2))
        status.visibility = View.GONE

        keysBox = LinearLayout(this)
        keysBox.orientation = LinearLayout.VERTICAL

        emojiBox = LinearLayout(this)
        emojiBox.orientation = LinearLayout.VERTICAL
        emojiBox.visibility = View.GONE

        root.addView(aiScroll, LinearLayout.LayoutParams(MATCH, dp(40)))
        root.addView(status, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(keysBox, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(emojiBox, LinearLayout.LayoutParams(MATCH, WRAP))

        renderKeys()
        return root
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::root.isInitialized) return

        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION
        secure = (cls == InputType.TYPE_CLASS_TEXT && (
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                        variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                        variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
                (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)

        val isText = cls == InputType.TYPE_CLASS_TEXT
        layer = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) 1 else 0
        autoCap = (info.inputType and InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) != 0
        val empty = currentInputConnection?.getTextBeforeCursor(1, 0).isNullOrEmpty()
        shift = autoCap && empty
        caps = false
        emojiOpen = false

        enterLabel = when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_SEARCH -> "🔍"
            EditorInfo.IME_ACTION_SEND -> "➤"
            EditorInfo.IME_ACTION_GO -> "→"
            EditorInfo.IME_ACTION_NEXT -> "→"
            EditorInfo.IME_ACTION_DONE -> "✓"
            else -> "⏎"
        }

        aiScroll.visibility = if (isText && !secure) View.VISIBLE else View.GONE
        status.visibility = View.GONE
        keysBox.visibility = View.VISIBLE
        emojiBox.visibility = View.GONE
        renderKeys()
    }

    // ---------------------------------------------------------------- clavier

    private fun renderKeys() {
        keysBox.removeAllViews()

        if (layer == 0) {
            val accentKeys = ACCENTS.map { c -> charKey(c.toString(), 1f, false) }
            keysBox.addView(row(38, accentKeys))
        }

        val rows = when (layer) {
            0 -> LETTER_ROWS
            1 -> SYM1_ROWS
            else -> SYM2_ROWS
        }

        keysBox.addView(row(46, rows[0].map { charKey(it.toString(), 1f, layer == 0) }))
        keysBox.addView(row(46, rows[1].map { charKey(it.toString(), 1f, layer == 0) }))

        val third = ArrayList<View>()
        if (layer == 0) {
            val label = if (caps) "⇪" else "⇧"
            val color = if (shift || caps) ACCENT_DARK else KEY_SPECIAL
            third.add(keyView(label, 1.5f, color) { onShiftTap() })
        } else if (layer == 1) {
            third.add(keyView("=\\<", 1.5f, KEY_SPECIAL, 16f) { layer = 2; renderKeys() })
        } else {
            third.add(keyView("123", 1.5f, KEY_SPECIAL, 16f) { layer = 1; renderKeys() })
        }
        for (c in rows[2]) third.add(charKey(c.toString(), 1f, layer == 0))
        third.add(backspaceKey(1.5f))
        keysBox.addView(row(46, third))

        val bottom = ArrayList<View>()
        if (layer == 0) {
            bottom.add(keyView("123", 1.4f, KEY_SPECIAL, 16f) { layer = 1; renderKeys() })
        } else {
            bottom.add(keyView("ABC", 1.4f, KEY_SPECIAL, 16f) { layer = 0; renderKeys() })
        }
        bottom.add(keyView("😀", 1.2f, KEY_SPECIAL, 20f) { openEmoji() })
        bottom.add(charKey(",", 1f, false))
        val space = keyView("Cuervo", 4f, KEY, 14f) { commit(" ") }
        space.setOnLongClickListener {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
            true
        }
        bottom.add(space)
        bottom.add(charKey(".", 1f, false))
        bottom.add(keyView(enterLabel, 1.5f, ACCENT, 20f) { pressEnter() })
        keysBox.addView(row(46, bottom))
    }

    private fun charKey(c: String, weight: Float, letter: Boolean): TextView {
        val shown = if (letter && (shift || caps)) c.uppercase() else c
        return keyView(shown, weight, KEY) {
            commit(shown)
            if (letter && shift && !caps) {
                shift = false
                renderKeys()
            }
        }
    }

    private fun onShiftTap() {
        val now = System.currentTimeMillis()
        if (now - lastShiftTap < 400) {
            caps = true
            shift = true
        } else if (caps) {
            caps = false
            shift = false
        } else {
            shift = !shift
        }
        lastShiftTap = now
        renderKeys()
    }

    private fun commit(text: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(text, 1)
        if (autoCap && text == " ") {
            val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
            if (before == ". " || before == "? " || before == "! ") {
                shift = true
                renderKeys()
            }
        }
    }

    private fun deleteBack() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
    }

    private fun backspaceKey(weight: Float): TextView {
        val v = keyView("⌫", weight, KEY_SPECIAL) { }
        val repeat = object : Runnable {
            override fun run() {
                deleteBack()
                ui.postDelayed(this, 55)
            }
        }
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    haptic(view)
                    deleteBack()
                    ui.postDelayed(repeat, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    ui.removeCallbacks(repeat)
                }
            }
            true
        }
        return v
    }

    private fun pressEnter() {
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    // ---------------------------------------------------------------- IA

    private fun buildAiBar() {
        aiRow.removeAllViews()
        undoBtn = chip("↩ Annuler") { undo() }
        undoBtn.visibility = View.GONE
        aiRow.addView(undoBtn)
        for ((label, action) in AI_ACTIONS) {
            aiRow.addView(chip(label) { runAi(action) })
        }
    }

    private fun runAi(action: String) {
        if (secure) return
        if (action == "repondre") {
            runReply()
            return
        }
        val ic = currentInputConnection ?: return
        if (Prefs.url(this).isBlank()) {
            showStatus("Configure l'IA dans l'application « Cuervo Clavier ».", 5000)
            return
        }
        val selected = ic.getSelectedText(0)?.toString()
        val useSel = !selected.isNullOrBlank()
        val src: String = if (!selected.isNullOrBlank()) selected else (ic.getTextBeforeCursor(1500, 0)?.toString() ?: "")
        if (src.isBlank()) {
            showStatus("Écris d'abord du texte (ou sélectionne-le).")
            return
        }
        showStatus("⏳ L'IA travaille…", 30000)
        val ctx: Context = this
        Thread {
            val r = AiClient.call(ctx, action, src)
            ui.post {
                val value = r.getOrNull()
                if (value != null) {
                    applyResult(src, useSel, value, action == "continuer")
                } else {
                    showStatus("⚠️ " + (r.exceptionOrNull()?.message ?: "Erreur IA"), 5000)
                }
            }
        }.start()
    }

    /** Lit la conversation affichée (ou le presse-papiers) et propose une réponse. */
    private fun runReply() {
        val ic = currentInputConnection ?: return
        if (Prefs.url(this).isBlank()) {
            showStatus("Configure l'IA dans l'application « Cuervo Clavier ».", 5000)
            return
        }
        var screen = ScreenReaderService.instance?.readScreen() ?: ""
        if (screen.isBlank()) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            screen = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
        }
        if (screen.isBlank()) {
            showStatus("Active la « lecture d'écran » dans l'application, ou copie le message puis réessaie.", 6000)
            return
        }
        val src = screen.takeLast(2500)
        showStatus("⏳ L'IA lit la conversation…", 30000)
        val ctx: Context = this
        Thread {
            val r = AiClient.call(ctx, "repondre", src)
            ui.post {
                val value = r.getOrNull()
                if (value == null) {
                    showStatus("⚠️ " + (r.exceptionOrNull()?.message ?: "Erreur IA"), 5000)
                } else {
                    val clean = value.trim()
                    ic.commitText(clean, 1)
                    lastOriginal = ""
                    lastInserted = clean
                    undoBtn.visibility = View.VISIBLE
                    showStatus("✓ Réponse proposée — modifie-la puis envoie. Touche 💬 pour une autre.", 4000)
                }
            }
        }.start()
    }

    private fun applyResult(src: String, useSel: Boolean, result: String, append: Boolean) {
        val clean = result.trim()
        val ic = currentInputConnection
        if (ic == null) {
            copyToClipboard(clean)
            showStatus("Résultat copié (champ fermé).")
            return
        }

        if (append) {
            val lead = if (src.endsWith(" ") || src.endsWith("\n")) "" else " "
            val inserted = if (useSel) src + lead + clean else lead + clean
            ic.commitText(inserted, 1)
            lastOriginal = if (useSel) src else ""
            lastInserted = inserted
        } else {
            val unchanged = if (useSel) {
                ic.getSelectedText(0)?.toString() == src
            } else {
                ic.getTextBeforeCursor(src.length, 0)?.toString() == src
            }
            if (!unchanged) {
                copyToClipboard(clean)
                showStatus("Le texte a changé : résultat copié dans le presse-papiers.", 5000)
                return
            }
            if (!useSel) ic.deleteSurroundingText(src.length, 0)
            ic.commitText(clean, 1)
            lastOriginal = src
            lastInserted = clean
        }
        undoBtn.visibility = View.VISIBLE
        showStatus("✓ Fait", 1500)
    }

    private fun undo() {
        val ic = currentInputConnection ?: return
        val inserted = lastInserted ?: return
        val before = ic.getTextBeforeCursor(inserted.length, 0)?.toString()
        if (before == inserted) {
            ic.deleteSurroundingText(inserted.length, 0)
            ic.commitText(lastOriginal ?: "", 1)
        } else {
            showStatus("Impossible d'annuler : le texte a changé.")
        }
        lastInserted = null
        lastOriginal = null
        undoBtn.visibility = View.GONE
    }

    private fun showStatus(msg: String, ms: Long = 3500) {
        status.text = msg
        status.visibility = View.VISIBLE
        ui.removeCallbacks(hideStatus)
        ui.postDelayed(hideStatus, ms)
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Cuervo", text))
    }

    // ---------------------------------------------------------------- émojis

    private fun openEmoji() {
        emojiOpen = true
        keysBox.visibility = View.GONE
        emojiBox.visibility = View.VISIBLE
        renderEmoji()
    }

    private fun closeEmoji() {
        emojiOpen = false
        emojiBox.visibility = View.GONE
        keysBox.visibility = View.VISIBLE
    }

    private fun renderEmoji() {
        emojiBox.removeAllViews()

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.addView(keyView("ABC", 1.4f, KEY_SPECIAL, 15f) { closeEmoji() })
        EMOJI_TABS.forEachIndexed { i, label ->
            val color = if (i == emojiTab) ACCENT_DARK else KEY
            tabs.addView(keyView(label, 1f, color, 18f) {
                emojiTab = i
                renderEmoji()
            })
        }
        tabs.addView(backspaceKey(1.4f))
        emojiBox.addView(tabs, LinearLayout.LayoutParams(MATCH, dp(46)))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        if (emojiTab == 0) fillStickers(col) else fillEmojis(col, EMOJI_SETS[emojiTab])

        val scroll = ScrollView(this)
        scroll.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))
        emojiBox.addView(scroll, LinearLayout.LayoutParams(MATCH, dp(190)))
    }

    private fun fillEmojis(col: LinearLayout, set: String) {
        val items = set.split(" ").filter { it.isNotBlank() }
        for (chunk in items.chunked(8)) {
            val cells = chunk.map { e ->
                val t = TextView(this)
                t.text = e
                t.textSize = 26f
                t.gravity = Gravity.CENTER
                t.setOnClickListener {
                    haptic(it)
                    commit(e)
                }
                t as View
            }
            col.addView(gridRow(cells, 8, 48))
        }
    }

    private fun fillStickers(col: LinearLayout) {
        val cells = ArrayList<View>()
        for (s in EmojiStore.builtin) {
            val f = EmojiStore.builtinFile(this, s)
            if (f.exists()) cells.add(stickerCell(f, s.alias))
        }
        for (f in EmojiStore.userFiles(this)) cells.add(stickerCell(f, null))

        val plus = TextView(this)
        plus.text = "＋"
        plus.textSize = 30f
        plus.setTextColor(MUTED)
        plus.gravity = Gravity.CENTER
        plus.setOnClickListener {
            val i = Intent(this, SettingsActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        cells.add(plus)

        for (chunk in cells.chunked(4)) col.addView(gridRow(chunk, 4, 68))
    }

    private fun stickerCell(file: File, alias: String?): View {
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        img.setPadding(dp(7), dp(7), dp(7), dp(7))
        val bmp = BitmapFactory.decodeFile(file.absolutePath)
        if (bmp != null) img.setImageBitmap(bmp)
        img.setOnClickListener {
            haptic(it)
            sendSticker(file, alias)
        }
        return img
    }

    private fun gridRow(cells: List<View>, perRow: Int, heightDp: Int): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (c in cells) r.addView(c, LinearLayout.LayoutParams(0, dp(heightDp), 1f))
        for (i in cells.size until perRow) r.addView(View(this), LinearLayout.LayoutParams(0, dp(heightDp), 1f))
        return r
    }

    private fun supportsImages(info: EditorInfo): Boolean {
        val types = EditorInfoCompat.getContentMimeTypes(info)
        return types.any { it.equals("image/png", true) || it.equals("image/*", true) }
    }

    private fun sendSticker(file: File, alias: String?) {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        var ok = false
        if (info != null && supportsImages(info)) {
            try {
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                val desc = ClipDescription(file.nameWithoutExtension, arrayOf("image/png"))
                ok = InputConnectionCompat.commitContent(
                    ic, info, InputContentInfoCompat(uri, desc, null),
                    InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null
                )
            } catch (e: Exception) {
                ok = false
            }
        }
        if (!ok) {
            if (alias != null) {
                ic.commitText(alias, 1)
                toast("Cette application n'accepte pas les images : émoji standard envoyé.")
            } else {
                toast("Cette application n'accepte pas les émojis image.")
            }
        }
    }

    // ---------------------------------------------------------------- outils d'affichage

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun haptic(v: View) {
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = radius.toFloat()
        return g
    }

    private fun keyBg(color: Int): StateListDrawable {
        val s = StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_pressed), rounded(KEY_PRESSED, dp(8)))
        s.addState(intArrayOf(), rounded(color, dp(8)))
        return s
    }

    private fun keyView(label: String, weight: Float, color: Int, size: Float = 20f, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = label
        v.setTextColor(Color.WHITE)
        v.textSize = size
        v.gravity = Gravity.CENTER
        v.background = keyBg(color)
        val lp = LinearLayout.LayoutParams(0, MATCH, weight)
        lp.setMargins(dp(2), dp(3), dp(2), dp(3))
        v.layoutParams = lp
        v.setOnClickListener {
            haptic(it)
            onClick()
        }
        return v
    }

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = label
        v.setTextColor(Color.WHITE)
        v.textSize = 14f
        v.gravity = Gravity.CENTER
        v.setPadding(dp(12), 0, dp(12), 0)
        v.background = rounded(CHIP, dp(16))
        val lp = LinearLayout.LayoutParams(WRAP, dp(32))
        lp.setMargins(dp(3), dp(4), dp(3), dp(4))
        v.layoutParams = lp
        v.setOnClickListener {
            haptic(it)
            onClick()
        }
        return v
    }

    private fun row(heightDp: Int, views: List<View>): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (v in views) r.addView(v)
        r.layoutParams = LinearLayout.LayoutParams(MATCH, dp(heightDp))
        return r
    }
}
