package co.cuervo.clavier

import android.content.Context

/** Réglages de l'IA (adresse de la fonction Supabase + clé publique « anon »). */
object Prefs {
    private const val FILE = "cuervo"
    private const val KEY_URL = "ai_url"
    private const val KEY_KEY = "ai_key"

    fun url(ctx: Context): String =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_URL, "") ?: ""

    fun key(ctx: Context): String =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_KEY, "") ?: ""

    fun save(ctx: Context, url: String, key: String) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY_URL, url.trim())
            .putString(KEY_KEY, key.trim())
            .apply()
    }
}
